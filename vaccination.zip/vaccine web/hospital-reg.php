




<link rel="stylesheet" href="style_login.css">

<form action="hospital-reg-check.php" method="POST" >
<center>
  <h1>Hospital Register</h1>
</center> 
<label>Name:</label>
  <input type="text" name="name" required>

  <label>Email:</label>
  <input type="email" name="email" required>

  <label>Password:</label>
  <input type="password" name="password" required>
<br>
  <button type="submit" class="button">Sign up</button>
  <button type="submit" class="button"><a href="hospital-login.php" style="color: black;">Login</a></button>
  



       
        </div>

</form>